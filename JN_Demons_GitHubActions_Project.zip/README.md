# Jorge And Nicolas Vs. Demons — Android V3.0

Projeto Android completo para compilar o jogo HTML como APK usando GitHub Actions.

## Estrutura

```text
.
├── .github/
│   └── workflows/
│       └── build.yml
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/
│       │   └── index.html
│       ├── java/com/jngames/demons/
│       │   └── MainActivity.kt
│       └── res/drawable-nodpi/
│           └── ic_launcher.png
├── gradle/wrapper/
│   └── gradle-wrapper.properties
├── build.gradle
├── gradle.properties
├── gradlew
├── gradlew.bat
└── settings.gradle
```

## Como compilar do zero no GitHub

1. Crie um repositório vazio no GitHub.
2. Envie todo o conteúdo desta pasta para a raiz do repositório, incluindo `.github`.
3. Abra **Actions** e permita workflows se o GitHub pedir.
4. Abra **Build Android APK** e clique em **Run workflow**. Um push para `main` também inicia a compilação.
5. Aguarde o job terminar com sucesso.
6. Abra a execução concluída e baixe o Artifact `Jorge-And-Nicolas-Vs-Demons-debug-APK`.
7. Extraia o Artifact e instale `app-debug.apk` no Android.

## Como o wrapper funciona neste repositório vazio

O Gradle Wrapper oficial precisa de um arquivo binário `gradle-wrapper.jar`. Esse JAR não é um arquivo de texto e não pode ser recriado corretamente copiando apenas o script shell.

Para que o repositório inicial não dependa de um JAR binário pré-incluído, `gradlew` e `gradlew.bat` são launchers de bootstrap que usam uma instalação Gradle local. No GitHub Actions, a etapa **Set up Gradle 8.9** instala Gradle 8.9 e a etapa **Generate official Gradle Wrapper** gera o `gradle-wrapper.jar` oficial e os scripts padrão antes de executar exatamente `./gradlew assembleDebug`.

Depois da primeira execução, o workflow também terá gerado `gradle/wrapper/gradle-wrapper.jar` no workspace do runner. Se quiser manter o wrapper oficial no repositório, faça commit do JAR e dos scripts gerados pelo Gradle Wrapper.

## Arquivos de configuração

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Kotlin Gradle Plugin: 2.0.21
- JDK: 17
- Android SDK: API 35
- `minSdk`: 24 (Android 7.0+)
- `targetSdk`: 35
- Orientação: paisagem
- Aplicativo: `com.jngames.demons`

## Teste local

Com JDK 17, Android SDK API 35, Build Tools 35.0.0 e Gradle 8.9 instalados:

```bash
gradle wrapper --gradle-version 8.9 --distribution-type bin
chmod +x ./gradlew
./gradlew assembleDebug
```

O APK ficará em:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Observações

- O HTML do jogo está incorporado em `app/src/main/assets/index.html`; não depende de servidor web.
- O aplicativo usa `WebViewAssetLoader` para carregar o conteúdo local de forma segura.
- O HTML chama `AndroidGame.onGameReady()` quando termina o carregamento; a tela nativa de carregamento só então desaparece.
- O APK de debug é assinado automaticamente com a chave de debug do Android. É adequado para teste/instalação manual, não para publicação final na Play Store.
- Não há bibliotecas nativas `.so` específicas de CPU, então o app não exige uma variante separada ARM 32/64 para o código Kotlin/WebView. A disponibilidade da WebView do sistema continua necessária.
- O ícone incluído é uma arte temporária baseada no ícone disponível no projeto anterior. Pode ser substituído em `app/src/main/res/drawable-nodpi/ic_launcher.png`.
