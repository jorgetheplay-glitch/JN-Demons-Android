package com.jngames.demons

import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebResourceRequest
import android.widget.FrameLayout
import android.widget.TextView
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat

class MainActivity : Activity() {
    private lateinit var gameView: WebView
    private lateinit var loadingView: TextView
    private lateinit var root: FrameLayout
    private var mainFrameFailed = false

    @Suppress("DEPRECATION")
    private fun applyImmersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        applyImmersiveMode()

        root = FrameLayout(this)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/res/", WebViewAssetLoader.ResourcesPathHandler(this))
            .build()

        gameView = WebView(this).apply {
            setBackgroundColor(Color.rgb(9, 8, 20))
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClientCompat() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): android.webkit.WebResourceResponse? {
                    return assetLoader.shouldInterceptRequest(request.url)
                }

                @Suppress("DEPRECATION")
                override fun shouldInterceptRequest(
                    view: WebView,
                    url: String
                ): android.webkit.WebResourceResponse? {
                    return assetLoader.shouldInterceptRequest(Uri.parse(url))
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    // The game is offline/local. Block navigation to external websites.
                    return request.url.host != "appassets.androidplatform.net"
                }

                override fun onReceivedError(
                    view: WebView,
                    request: WebResourceRequest,
                    error: android.webkit.WebResourceError
                ) {
                    super.onReceivedError(view, request, error)
                    if (request.isForMainFrame) {
                        showError(error.description?.toString() ?: "Could not load the game.")
                    }
                }
            }

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                cacheMode = WebSettings.LOAD_DEFAULT
                allowFileAccess = false
                allowContentAccess = false
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false
                builtInZoomControls = false
                displayZoomControls = false
                setSupportZoom(false)
                mediaPlaybackRequiresUserGesture = true
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
            }

            addJavascriptInterface(GameBridge(), "AndroidGame")
        }

        loadingView = TextView(this).apply {
            text = "J&N\nJORGE AND NICOLAS VS. DEMONS\n\nCARREGANDO RECURSOS..."
            setTextColor(Color.rgb(255, 211, 176))
            textSize = 19f
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(12, 9, 23))
            setPadding(32, 32, 32, 32)
        }

        root.addView(
            gameView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        root.addView(
            loadingView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        setContentView(root)
        gameView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private inner class GameBridge {
        @JavascriptInterface
        fun onGameReady() {
            runOnUiThread {
                if (!mainFrameFailed && ::loadingView.isInitialized) {
                    loadingView.animate()
                        .alpha(0f)
                        .setDuration(200)
                        .withEndAction { loadingView.visibility = View.GONE }
                        .start()
                }
            }
        }
    }

    private fun showError(message: String) {
        mainFrameFailed = true
        runOnUiThread {
            if (::loadingView.isInitialized) {
                loadingView.alpha = 1f
                loadingView.text =
                    "JORGE & NICOLAS VS. DEMONS\n\nFalha ao carregar o jogo:\n$message\n\nFeche e abra o aplicativo novamente."
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    override fun onPause() {
        if (::gameView.isInitialized) gameView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::gameView.isInitialized) {
            gameView.onResume()
            applyImmersiveMode()
        }
    }

    override fun onDestroy() {
        if (::gameView.isInitialized) {
            gameView.stopLoading()
            gameView.loadUrl("about:blank")
            gameView.removeAllViews()
            gameView.destroy()
        }
        super.onDestroy()
    }
}
