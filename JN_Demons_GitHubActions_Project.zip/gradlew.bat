@echo off
rem Bootstrap launcher for a clean GitHub repository.
rem GitHub Actions installs Gradle 8.9 and generates the official wrapper:
rem   gradle wrapper --gradle-version 8.9 --distribution-type bin
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle is not installed. Install Gradle 8.9 or run the GitHub Actions workflow.
exit /b 127
